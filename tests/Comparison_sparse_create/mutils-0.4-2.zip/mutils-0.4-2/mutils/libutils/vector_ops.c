#include "utils.h"
#include "mtypes.h"
#include "vector_ops.h"

#if !HAVE_INLINE
STREAM_VALUES_1_C
STREAM_VALUES_2_C
#endif
