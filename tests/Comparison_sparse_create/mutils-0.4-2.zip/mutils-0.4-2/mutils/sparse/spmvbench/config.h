/* #define DEBUG */
/* #define USE_PREFETCHING */
/* #define USE_METIS */
/* #undef USE_CUSTOM_BARRIER */
/* #undef USE_NUMA_SUPPORT */

